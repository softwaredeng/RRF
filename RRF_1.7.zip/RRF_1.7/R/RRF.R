"RRF" <-
function(x, ...)
  UseMethod("RRF")
